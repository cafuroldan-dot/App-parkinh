# Parcheggi Eboli — APK Android

Questa cartella contiene il progetto Android della versione 1.0.

## Compatibilità
Configurazione Android:
- minSdk 23 (Android 6.0 e successivi)
- targetSdk 35
- architettura indipendente dall'app: usa WebView e non richiede servizi Google per la schermata principale.

## Generazione dell'APK
Apri il progetto in Android Studio e usa:
Build → Build APK(s)

File risultante:
app/build/outputs/apk/debug/app-debug.apk

Per distribuirlo su telefoni Android, puoi copiare l'APK e aprirlo sul telefono. Android potrebbe chiedere di consentire l'installazione da questa sorgente.

Nota: non è possibile promettere compatibilità con "tutte" le versioni Android esistenti. Questa configurazione copre Android 6.0+; versioni molto vecchie di Android non sono supportate.
