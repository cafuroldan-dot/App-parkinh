package it.parcheggieboli.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.webViewClient = WebViewClient()

        webView.addJavascriptInterface(ShareBridge(), "AndroidShare")
        setContentView(webView)

        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class ShareBridge {
        @android.webkit.JavascriptInterface
        fun share(text: String) {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }

            // Mostra il pannello di condivisione: l'utente può scegliere WhatsApp
            // oppure un altro gruppo/app disponibile sul telefono.
            val chooser = Intent.createChooser(sendIntent, "Condividi parcheggio")
            startActivity(chooser)
        }

        @android.webkit.JavascriptInterface
        fun openMaps() {
            val uri = Uri.parse("geo:40.61635,15.05656?q=Piazzetta+San+Giacomo,+Eboli")
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        }
    }
}