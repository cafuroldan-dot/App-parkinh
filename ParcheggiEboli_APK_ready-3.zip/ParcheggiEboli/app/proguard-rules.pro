# Regole ProGuard/R8 personalizzabili.
