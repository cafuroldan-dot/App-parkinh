# Parcheggi Eboli — versione 1.0

Prima versione Android dell'app richiesta:
- mappa centrata su Piazzetta San Giacomo, Eboli;
- 11 posti totali / 11 liberi come valore iniziale dimostrativo;
- pulsanti +/- per aggiornare manualmente i posti liberi;
- salvataggio locale del numero;
- condivisione del messaggio tramite il pannello Android, quindi WhatsApp può essere scelto come destinazione;
- pulsante per aprire le indicazioni stradali;
- nessun pagamento o account.

## Come generare l'APK
1. Aprire la cartella in Android Studio.
2. Lasciare che Android Studio sincronizzi Gradle e scarichi le dipendenze.
3. Selezionare `Build > Build APK(s)`.
4. L'APK debug verrà prodotto nella cartella `app/build/outputs/apk/debug/`.

## Nota sui dati
Il numero dei posti è manuale in questa prima versione. Per avere dati reali condivisi tra più telefoni serve un piccolo backend/database e un sistema con cui aggiornare i posti.